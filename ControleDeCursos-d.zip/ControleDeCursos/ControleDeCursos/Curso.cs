﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace ControleDeCursos
{
    class Curso
    {
        public int codigoCurso;
        public string nomeCurso, conteudoProgramatico, cargaHoraria;
        public double valorMensalidade;

        public void CadastrarCurso()
        {

        }

        public void AlterarCurso()
        {

        }

        public void ExcluirCurso()
        {

        }

        public DataTable ListarCursos()     //Requer: using System.Data;
        {
            return null;
        }
    }
}
